
<ul class="admincp_list">
    <li><a href="index.php?action=quanlydanhmucsanpham&query=them">Quản Lý Danh Mục Sản Phẩm</a></li>
    <li><a href="index.php?action=quanlysp&query=them">Quản Lý Sản Phẩm</a></li>
    <li><a href="index.php?action=quanlybaiviet&query=them">Quản Lý Bài Viết</a></li>
    <li><a href="index.php?action=quanlydanhmucbaiviet&query=them">Quản Lý Danh Mục Bài Viết</a></li>
    <li><a href="index.php?action=quanlydonhang&query=lietke">Quản Lý Đơn Hàng</a></li>
</ul>
<style>
   ul.admincp_list{
  padding: 0;
  margin: 0;
  list-style: none;
}
ul.admincp_list li{
    float: left;
    margin: 5px;
}
.clear{
    clear:both;
}
    </style>