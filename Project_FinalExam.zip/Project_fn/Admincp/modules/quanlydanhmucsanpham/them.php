<p>Them Danh Muc San Pham</p>
<table border="1px" width="50%" style="border-collapse:collapse;">
<form method="post" action="modules/quanlydanhmucsanpham/xuly.php">
 <tr>
    <td>Ten danh muc</td>
    <td><input type="text" name="tendanhmuc" value=""></td>
   
  </tr>
  <tr>
    <td>Thu tu</td>
    <td><input type="text" name="thutu" value=""></td>
  </tr>
  <tr>
    <td colspan="2"><input type="submit" name="themdanhmuc" value="them danh muc san pham"></td>
  </tr>

  </form>
</table>