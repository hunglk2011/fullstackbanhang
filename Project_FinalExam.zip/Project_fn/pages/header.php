<div class="header">
 <img src="images/banner.jpg" width="100%" height="140px">
 </div>