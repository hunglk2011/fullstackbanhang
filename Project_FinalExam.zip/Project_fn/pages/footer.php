<div class="footer">
            <span>
        <h3>Trang web bán cafe Nhóm 2</h3>
        <p>Được thiết kế dựa trên trang web bán cafe của những thương hiệu uy tín</p>
        <p>280 Đ. An D. Vương, Phường 4, Quận 5, Thành phố Hồ Chí Minh</p>
        <i class="fa fa-facebook" style="font-size:24px"></i>  
        <i class="fa fa-github" style="font-size:24px"></i>
        <i class="fa fa-youtube-square" style="font-size:24px"></i>  

        </span>
  
</div>